#include "header.h"

int main()
{
    int vec[5] = {3,1,5,2,6};
    int numero;
    Lista lista;
    crearLista(&lista);
    insertarEnListaOrdenada(&lista,&vec[0],sizeof(int),cmpEnteros);
    insertarEnListaOrdenada(&lista,&vec[1],sizeof(int),cmpEnteros);
    insertarEnListaOrdenada(&lista,&vec[2],sizeof(int),cmpEnteros);
    insertarEnListaOrdenada(&lista,&vec[3],sizeof(int),cmpEnteros);
    insertarEnListaOrdenada(&lista,&vec[4],sizeof(int),cmpEnteros);
    mostrarLista(&lista,mostrarEnteros);

    return 0;
}


void crearLista(Lista* lista)
{
    *lista = NULL;
}

int insertalAlFinal(Lista* lista,const void* dato,size_t tamElem)
{
    tNodo* nuevo;
    while(*lista)
        lista = &(*lista)->sig;
    if((nuevo = (tNodo*)malloc(sizeof(tNodo))) == NULL || (nuevo->info = malloc(tamElem)) == NULL)
        return 1;
    memcpy(nuevo->info,dato,tamElem);
    nuevo->sig = NULL;
    nuevo->tamInfo = tamElem;
    *lista = nuevo;
    return 0;
}

int insertarAlPrincipio(Lista* lista,const void* dato,size_t tamElem)
{
    tNodo* nuevo;
    if((nuevo =(tNodo*)malloc(sizeof(tNodo))) == NULL || (nuevo->info=malloc(tamElem)) == NULL)
        return 1;
    memcpy(nuevo->info,dato,tamElem);
    nuevo->sig = *lista;
    nuevo->tamInfo = tamElem;
    *lista = nuevo;
    return 0;
}

int verUltimo(const Lista* lista, void* dato,size_t tamElem)
{
    if(*lista == NULL)
        return 1;

    memcpy(dato,(*lista)->info,tamElem);
    return 0;
}

void mostrarEnteros(const void* dato)
{
    int elemento = *(int*)dato;
    printf("%d",elemento);
}

void mostrarLista(const Lista* lista,void(*mostrar)(const void* dato))
{

    while(*lista)
    {
        mostrar((*lista)->info);
        lista = &(*lista)->sig;
    }

}

int insertarEnListaOrdenada(Lista* lista,const void* elem,size_t tamElem,int(*cmp)(const void*,const void*))
{
    while((*lista) && cmp(elem,(*lista)->info)>0)
        lista = &(*lista)->sig;

    if(*lista && cmp(elem,(*lista)->info)==0)
    {
        tNodo* aux = lista;
        lista = &(*lista)->sig;
        free(aux->info);
        free(aux);
        return 1;
    }
    return 0;
}

int cmpEnteros(const void* dato1,const void* dato2)
{
    int numero1 = *(int*)dato1;
    int numero2 = *(int*)dato2;
    printf("%d",numero1-numero2);
    return numero1 - numero2;
}
