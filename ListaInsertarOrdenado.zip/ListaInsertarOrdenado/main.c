#include "header.h"

int main()
{
    int vec[5] = {3,1,5,2,6};
    int numero;
    Lista lista;
    crearLista(&lista);
    printf("hola");
    insertalAlFinal(&lista,&vec[0],sizeof(int));
    insertalAlFinal(&lista,&vec[1],sizeof(int));
    insertarAlPrincipio(&lista,&vec[2],sizeof(int));
    insertarAlPrincipio(&lista,&vec[3],sizeof(int));
    insertalAlFinal(&lista,&vec[4],sizeof(int));
    verUltimo(&lista,&numero,sizeof(int));
    mostrarLista(&lista,mostrarEnteros);

    return 0;
}


void crearLista(Lista* lista)
{
    *lista = NULL;
}

int insertalAlFinal(Lista* lista,const void* dato,size_t tamElem)
{
    tNodo* nuevo;
    while(*lista)
        lista = &(*lista)->sig;
    if((nuevo = (tNodo*)malloc(sizeof(tNodo))) == NULL || (nuevo->info = malloc(tamElem)) == NULL)
        return 1;
    memcpy(nuevo->info,dato,tamElem);
    nuevo->tamInfo = tamElem;
    *lista = nuevo;
    return 0;
}

int insertarAlPrincipio(Lista* lista,const void* dato,size_t tamElem)
{
    tNodo* nuevo;
    if((nuevo =(tNodo*)malloc(sizeof(tNodo))) == NULL || (nuevo->info=malloc(tamElem)) == NULL)
        return 1;
    memcpy(nuevo->info,dato,tamElem);
    nuevo->sig = *lista;
    nuevo->tamInfo = tamElem;
    *lista = nuevo;
    return 0;
}

int verUltimo(const Lista* lista, void* dato,size_t tamElem)
{
    if(*lista == NULL)
        return 1;

    memcpy(dato,(*lista)->info,tamElem);
    return 0;
}

void mostrarEnteros(const void* dato)
{
    int elemento = *(int*)dato;
    printf("%d",elemento);
}

void mostrarLista(const Lista* lista,void(*mostrar)(const void* dato))
{

    while(*lista)
    {
        mostrar((*lista)->info);
        lista = &(*lista)->sig;
    }

}

