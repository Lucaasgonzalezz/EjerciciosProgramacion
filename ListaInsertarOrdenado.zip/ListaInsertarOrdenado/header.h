#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct sNodo
{
    void* info;
    unsigned tamInfo;
    struct sNodo* sig;
}tNodo;

typedef tNodo* Lista;

void crearLista(Lista* lista);
int insertarAlPrincipio(Lista* lista,const void* dato,size_t tamElem);
int insertalAlFinal(Lista* lista,const void* dato,size_t tamElem);
void mostrarLista(const Lista* lista,void(*mostrar)(const void* dato));
void mostrarEnteros(const void* dato);
int cmpEnteros(const void* dato1,const void* dato2);
int verUltimo(const Lista* lista, void* dato,size_t tamElem);
int insertarEnListaOrdenada(Lista* lista,const void* elem,size_t tamElem,int(*cmp)(const void*,const void*));




#endif // HEADER_H_INCLUDED
